<?php
/**
 * Flat garment illustrations, used when a product has no photo yet.
 * They keep the shop looking designed during the draft phase and
 * disappear the moment a real product image is uploaded.
 *
 * @package Aeverything
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ae_garment_svgs() {
	return array(
		'crop'  => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Crop top"><path d="M33 47C31 31 37 21 45 17" stroke="#FF6E95" stroke-width="7" stroke-linecap="round"/><path d="M67 47c2-16-4-26-12-30" stroke="#FF6E95" stroke-width="7" stroke-linecap="round"/><path d="M28 44c12 6 32 6 44 0l2 34c0 11-8 17-24 17s-24-6-24-17Z" fill="#FF5C86"/><path d="M28 44c12 6 32 6 44 0l-.7 11c-11.4 5-31 5-42.4 0Z" fill="#FF9DBB"/><path d="M50 72v18" stroke="#fff" stroke-width="1.6" opacity=".5"/></svg>',

		'legg'  => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Leggings"><path d="M26 22h48l-4 36-5 54H52l-2-52-2 52H35l-5-54Z" fill="#FF5C86"/><path d="M26 22h48v11H26Z" fill="#FF9DBB"/><path d="M36 58h10M54 58h10" stroke="#fff" stroke-width="1.6" opacity=".45" stroke-linecap="round"/></svg>',

		'hood'  => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Zip hoodie"><path d="M29 41 12 53l5 37h13Z" fill="#FF9DBB"/><path d="M71 41l17 12-5 37H70Z" fill="#FF9DBB"/><path d="M29 39c6-6 13-9 21-9s15 3 21 9v63H29Z" fill="#FF5C86"/><path d="M36 35c2-14 8-21 14-21s12 7 14 21c-6-6-22-6-28 0Z" fill="#FF9DBB"/><path d="M50 33v69" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/><circle cx="50" cy="45" r="2.6" fill="#fff"/></svg>',

		'boxer' => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Boxer brief"><path d="M22 36h56v27c0 15-8 24-17 24-6 0-8-7-11-16-3 9-5 16-11 16-9 0-17-9-17-24Z" fill="#FF5C86"/><path d="M22 36h56v12H22Z" fill="#FF9DBB"/><path d="M34 42h10" stroke="#fff" stroke-width="1.8" opacity=".55" stroke-linecap="round"/></svg>',

		'hat'   => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Bucket hat"><path d="M29 63c0-25 8-37 21-37s21 12 21 37Z" fill="#FF5C86"/><path d="M17 63c0-6 13-9 33-9s33 3 33 9c0 9-15 15-33 15s-33-6-33-15Z" fill="#FF9DBB"/><path d="M33 58h34" stroke="#fff" stroke-width="1.8" opacity=".5" stroke-linecap="round"/></svg>',

		'socks' => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Socks"><path d="M22 24h17v38c0 8 6 10 12 11v15H36c-9 0-14-8-14-17Z" fill="#FF5C86"/><path d="M22 24h17v9H22Z" fill="#FF9DBB"/><path d="M57 30h17v38c0 8 6 10 12 11v15H71c-9 0-14-8-14-17Z" fill="#FF7FA3"/><path d="M57 30h17v9H57Z" fill="#FFB9CE"/></svg>',

		'tee'   => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Tee"><path d="M31 36 14 47l6 18 11-6Z" fill="#FF9DBB"/><path d="M69 36l17 11-6 18-11-6Z" fill="#FF9DBB"/><path d="M31 34c6-5 12-7 19-7s13 2 19 7v64H31Z" fill="#FF5C86"/><path d="M41 29c2 7 16 7 18 0" stroke="#FF9DBB" stroke-width="4" stroke-linecap="round"/></svg>',

		'cap'   => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Cap"><path d="M26 60c0-22 10-33 24-33s24 11 24 33Z" fill="#FF5C86"/><path d="M74 55c10 1 15 5 15 10H26v-10Z" fill="#FF9DBB"/><circle cx="50" cy="29" r="3.4" fill="#FF9DBB"/></svg>',

		'pants' => '<svg viewBox="0 0 100 120" fill="none" role="img" aria-label="Pants"><path d="M24 20h52l-3 40-4 52H55l-3-50-3 50H35l-4-52Z" fill="#FF5C86"/><path d="M24 20h52v12H24Z" fill="#FF9DBB"/><path d="M31 40h14M55 40h14" stroke="#fff" stroke-width="1.5" opacity=".4" stroke-linecap="round"/></svg>',
	);
}

/**
 * Pick a garment that matches the product name, so a hoodie looks like a
 * hoodie rather than whatever happened to be next in the list.
 */
function ae_garment( $post_id = null, $echo = true ) {
	$svgs = ae_garment_svgs();
	$name = strtolower( $post_id ? get_the_title( $post_id ) : '' );

	$map = array(
		'crop'    => 'crop',
		'bra'     => 'crop',
		'legging' => 'legg',
		'hood'    => 'hood',
		'sweat'   => 'hood',
		'jacket'  => 'hood',
		'boxer'   => 'boxer',
		'brief'   => 'boxer',
		'under'   => 'boxer',
		'bucket'  => 'hat',
		'hat'     => 'hat',
		'sock'    => 'socks',
		'tee'     => 'tee',
		't-shirt' => 'tee',
		'shirt'   => 'tee',
		'top'     => 'tee',
		'cap'     => 'cap',
		'pant'    => 'pants',
		'jogger'  => 'pants',
		'short'   => 'pants',
		'gym'     => 'legg',
	);

	$key = 'tee';
	foreach ( $map as $needle => $slug ) {
		if ( false !== strpos( $name, $needle ) ) {
			$key = $slug;
			break;
		}
	}

	$svg = isset( $svgs[ $key ] ) ? $svgs[ $key ] : reset( $svgs );

	if ( ! $echo ) {
		return $svg;
	}
	echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput -- static, theme-authored SVG markup.
}
